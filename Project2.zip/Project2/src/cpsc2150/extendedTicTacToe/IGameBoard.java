package cpsc2150.extendedTicTacToe;

public interface IGameBoard {


}
